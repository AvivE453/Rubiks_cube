#include <Camera.h>
#include <glm/gtx/string_cast.hpp>
#include "Cube.h"

void Camera::SetOrthographic(float near, float far)
{
    m_Near = near;
    m_Far = far;

    // Rest Projection and View matrices
    m_Projection = glm::ortho(m_Left, m_Right, m_Bottom, m_Top, near, far);
    m_View = glm::lookAt(m_Position, m_Position + m_Orientation, m_Up);
}

void Camera::SetPerspective(float near, float far)
{
    m_Near = near;
    m_Far = far;

    // Rest Projection and View matrices
    m_Projection = glm::perspective(glm::radians(45.0f), 1.0f, near, far);
    m_View = glm::lookAt(m_Position, m_Position + m_Orientation, m_Up);
}

/////////////////////
// Input Callbacks //
/////////////////////

void KeyCallback(GLFWwindow *window, int key, int scanCode, int action, int mods)
{
    Camera *camera = (Camera *)glfwGetWindowUserPointer(window);
    if (!camera)
    {
        std::cout << "Warning: Camera wasn't set as the Window User Pointer! KeyCallback is skipped" << std::endl;
        return;
    }

    if (action == GLFW_PRESS || action == GLFW_REPEAT)
    {
        RubiksCube rubi = camera->getRubiksCube();
        // std::vector<std::vector<std::vector<Cube *>>> cube_indexes = rubi.getCubeIndexes();
        std::vector<std::vector<std::vector<Cube *>>> &cube_indexes = rubi.getCubeIndexes();

        std::vector<Cube *> temp;
        // temp.resize(3 * 3);
        size_t i, j;
        switch (key)
        {
        case GLFW_KEY_R:
            temp.clear();
            std::cout << "Starting Right (R) rotation..." << std::endl;

            for (int height = 0; height < 3; height++)
            {
                for (int depth = 0; depth < 3; depth++)
                {
                    assert(cube_indexes[height][depth][2] != nullptr);
                    temp.push_back(cube_indexes[height][depth][2]);
                    std::cout << "Collected cube_indexes[" << height << "][" << depth << "][2]: " << cube_indexes[height][depth][2] << std::endl;
                }
            }

            for (j = 0; j < temp.size(); j++)
            {
                assert(temp[j] != nullptr);
                glm::mat4 trans = temp[j]->getTranslationMatrix();
                glm::mat4 rot = temp[j]->getRotationMatrix();

                glm::vec3 pos = glm::vec3(trans[3][0], trans[3][1], trans[3][2]);
                std::cout << "Cube " << j << " Position: " << glm::to_string(pos) << std::endl;

                glm::mat4 modelMatrix = glm::translate(glm::mat4(1.0f), -pos);
                modelMatrix = glm::rotate(modelMatrix, glm::radians(-90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
                modelMatrix = glm::translate(modelMatrix, pos);

                glm::mat4 final = modelMatrix * rot;
                std::cout << "Cube " << j << " Updated Rotation Matrix: " << glm::to_string(final) << std::endl;

                temp[j]->setRotationMatrix(final);
            }

            i = 0;
            for (int depth = 3 - 1; depth >= 0; depth--)
            {
                for (int height = 0; height < 3; height++)
                {
                    std::cout << "Updating cube_indexes[" << height << "][" << depth << "][2] with temp[" << i << "]" << std::endl;
                    cube_indexes[height][depth][2] = temp[i++];
                }
            }

            std::cout << "Current state of cube_indexes:" << std::endl;
            for (int height = 0; height < 3; height++)
            {
                for (int depth = 0; depth < 3; depth++)
                {
                    for (int width = 0; width < 3; width++)
                    {
                        std::cout << "cube_indexes[" << height << "][" << depth << "][" << width << "]: "
                                  << cube_indexes[height][depth][width] << std::endl;
                    }
                }
            }
            std::cout << "Right (R) rotation completed." << std::endl;
            break;

        case GLFW_KEY_L:
            temp.clear();
            std::cout << "Starting Left (L) rotation..." << std::endl;

            for (int height = 0; height < 3; height++)
            {
                for (int depth = 0; depth < 3; depth++)
                {
                    assert(cube_indexes[height][depth][0] != nullptr);
                    temp.push_back(cube_indexes[height][depth][0]);
                    std::cout << "Collected cube_indexes[" << height << "][" << depth << "][0]: " << cube_indexes[height][depth][0] << std::endl;
                }
            }

            for (j = 0; j < temp.size(); j++)
            {
                assert(temp[j] != nullptr);
                glm::mat4 trans = temp[j]->getTranslationMatrix();
                glm::mat4 rot = temp[j]->getRotationMatrix();

                glm::vec3 pos = glm::vec3(trans[3][0], trans[3][1], trans[3][2]);
                std::cout << "Cube " << j << " Position: " << glm::to_string(pos) << std::endl;

                glm::mat4 modelMatrix = glm::translate(glm::mat4(1.0f), -pos);
                modelMatrix = glm::rotate(modelMatrix, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
                modelMatrix = glm::translate(modelMatrix, pos);

                glm::mat4 final = modelMatrix * rot;
                std::cout << "Cube " << j << " Updated Rotation Matrix: " << glm::to_string(final) << std::endl;

                temp[j]->setRotationMatrix(final);
            }

            i = 0;
            for (int depth = 0; depth < 3; depth++)
            {
                for (int height = 3 - 1; height >= 0; height--)
                {
                    std::cout << "Updating cube_indexes[" << height << "][" << depth << "][0] with temp[" << i << "]" << std::endl;
                    cube_indexes[height][depth][0] = temp[i++];
                }
            }

            std::cout << "Current state of cube_indexes:" << std::endl;
            for (int height = 0; height < 3; height++)
            {
                for (int depth = 0; depth < 3; depth++)
                {
                    for (int width = 0; width < 3; width++)
                    {
                        std::cout << "cube_indexes[" << height << "][" << depth << "][" << width << "]: "
                                  << cube_indexes[height][depth][width] << std::endl;
                    }
                }
            }
            std::cout << "Left (L) rotation completed." << std::endl;
            break;

        case GLFW_KEY_F:
            temp.clear();
            std::cout << "Starting Front (F) rotation..." << std::endl;

            // Collect pointers from the front face (y = 2)
            for (int height = 0; height < 3; height++)
            {
                for (int width = 0; width < 3; width++)
                {
                    assert(cube_indexes[height][2][width] != nullptr);
                    temp.push_back(cube_indexes[height][2][width]);
                    std::cout << "Collected cube_indexes[" << height << "][2][" << width << "]: " << cube_indexes[height][2][width] << std::endl;
                }
            }

            // Rotate each cube on the front face
            for (j = 0; j < temp.size(); j++)
            {
                assert(temp[j] != nullptr);
                glm::mat4 trans = temp[j]->getTranslationMatrix();
                glm::mat4 rot = temp[j]->getRotationMatrix();

                glm::vec3 pos = glm::vec3(trans[3][0], trans[3][1], trans[3][2]);
                std::cout << "Cube " << j << " Position: " << glm::to_string(pos) << std::endl;

                glm::mat4 modelMatrix = glm::translate(glm::mat4(1.0f), -pos);
                modelMatrix = glm::rotate(modelMatrix, glm::radians(-90.0f), glm::vec3(0.0f, 1.0f, 0.0f));
                modelMatrix = glm::translate(modelMatrix, pos);

                glm::mat4 final = modelMatrix * rot;
                std::cout << "Cube " << j << " Updated Rotation Matrix: " << glm::to_string(final) << std::endl;

                temp[j]->setRotationMatrix(final);
            }

            // Update the front face (y = 2)
            i = 0;
            for (int width = 0; width < 3; width++)
            {
                for (int height = 2; height >= 0; height--)
                {
                    cube_indexes[height][2][width] = temp[i++];
                }
            }

            // Update neighboring faces (U, R, D, L)
            Cube *temp_edge[3];

            // Save the top row of the front face (U -> F)
            for (int i = 0; i < 3; i++)
            {
                temp_edge[i] = cube_indexes[2][2][i];
                cube_indexes[2][2][i] = cube_indexes[2 - i][0][2]; // Move R -> F
            }

            // Save right column of the front face (D -> R)
            for (int i = 0; i < 3; i++)
            {
                cube_indexes[2 - i][0][2] = cube_indexes[0][0][2 - i];
            }

            for (int i = 0; i < 3; i++)
            {
                cube_indexes[0][0][2 - i] = temp_edge[i]; // F -> L
            }

            std::cout << "Front (F) rotation completed." << std::endl;

            // Print updated cube state
            std::cout << "Updated state of cube_indexes after Front rotation:" << std::endl;
            for (int h = 0; h < 3; h++)
            {
                for (int d = 0; d < 3; d++)
                {
                    for (int w = 0; w < 3; w++)
                    {
                        std::cout << "cube_indexes[" << h << "][" << d << "][" << w << "]: " << cube_indexes[h][d][w] << std::endl;
                    }
                }
            }
            break;

        case GLFW_KEY_B:
            temp.clear();
            std::cout << "Starting Back (B) rotation..." << std::endl;

            for (int height = 0; height < 3; height++)
            {
                for (int width = 0; width < 3; width++)
                {
                    assert(cube_indexes[height][0][width] != nullptr);
                    temp.push_back(cube_indexes[height][0][width]);
                    std::cout << "Collected cube_indexes[" << height << "][0][" << width << "]: " << cube_indexes[height][0][width] << std::endl;
                }
            }

            for (j = 0; j < temp.size(); j++)
            {
                assert(temp[j] != nullptr);
                glm::mat4 trans = temp[j]->getTranslationMatrix();
                glm::mat4 rot = temp[j]->getRotationMatrix();

                glm::vec3 pos = glm::vec3(trans[3][0], trans[3][1], trans[3][2]);
                std::cout << "Cube " << j << " Position: " << glm::to_string(pos) << std::endl;

                glm::mat4 modelMatrix = glm::translate(glm::mat4(1.0f), -pos);
                modelMatrix = glm::rotate(modelMatrix, glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
                modelMatrix = glm::translate(modelMatrix, pos);

                glm::mat4 final = modelMatrix * rot;
                std::cout << "Cube " << j << " Updated Rotation Matrix: " << glm::to_string(final) << std::endl;

                temp[j]->setRotationMatrix(final);
            }

            i = 0;
            for (int width = 3 - 1; width >= 0; width--)
            {
                for (int height = 0; height < 3; height++)
                {
                    std::cout << "Updating cube_indexes[" << height << "][0][" << width << "] with temp[" << i << "]" << std::endl;
                    cube_indexes[height][0][width] = temp[i++];
                }
            }

            std::cout << "Current state of cube_indexes:" << std::endl;
            for (int height = 0; height < 3; height++)
            {
                for (int depth = 0; depth < 3; depth++)
                {
                    for (int width = 0; width < 3; width++)
                    {
                        std::cout << "cube_indexes[" << height << "][" << depth << "][" << width << "]: "
                                  << cube_indexes[height][depth][width] << std::endl;
                    }
                }
            }
            std::cout << "Back (B) rotation completed." << std::endl;
            break;

        case GLFW_KEY_U:
            temp.clear();
            std::cout << "Starting Up (U) rotation..." << std::endl;

            for (int depth = 0; depth < 3; depth++)
            {
                for (int width = 0; width < 3; width++)
                {
                    assert(cube_indexes[2][depth][width] != nullptr);
                    temp.push_back(cube_indexes[2][depth][width]);
                    std::cout << "Collected cube_indexes[2][" << depth << "][" << width << "]: " << cube_indexes[2][depth][width] << std::endl;
                }
            }

            for (j = 0; j < temp.size(); j++)
            {
                assert(temp[j] != nullptr);
                glm::mat4 trans = temp[j]->getTranslationMatrix();
                glm::mat4 rot = temp[j]->getRotationMatrix();

                glm::vec3 pos = glm::vec3(trans[3][0], trans[3][1], trans[3][2]);
                std::cout << "Cube " << j << " Position: " << glm::to_string(pos) << std::endl;

                glm::mat4 modelMatrix = glm::translate(glm::mat4(1.0f), -pos);
                modelMatrix = glm::rotate(modelMatrix, glm::radians(-90.0f), glm::vec3(0.0f, 1.0f, 0.0f));
                modelMatrix = glm::translate(modelMatrix, pos);

                glm::mat4 final = modelMatrix * rot;
                std::cout << "Cube " << j << " Updated Rotation Matrix: " << glm::to_string(final) << std::endl;

                temp[j]->setRotationMatrix(final);
            }

            i = 0;
            for (int width = 3 - 1; width >= 0; width--)
            {
                for (int depth = 0; depth < 3; depth++)
                {
                    std::cout << "Updating cube_indexes[2][" << depth << "][" << width << "] with temp[" << i << "]" << std::endl;
                    cube_indexes[2][depth][width] = temp[i++];
                }
            }

            std::cout << "Current state of cube_indexes:" << std::endl;
            for (int height = 0; height < 3; height++)
            {
                for (int depth = 0; depth < 3; depth++)
                {
                    for (int width = 0; width < 3; width++)
                    {
                        std::cout << "cube_indexes[" << height << "][" << depth << "][" << width << "]: "
                                  << cube_indexes[height][depth][width] << std::endl;
                    }
                }
            }
            std::cout << "Up (U) rotation completed." << std::endl;
            break;

        case GLFW_KEY_D:
            temp.clear();
            std::cout << "Starting Down (D) rotation..." << std::endl;

            for (int depth = 0; depth < 3; depth++)
            {
                for (int width = 0; width < 3; width++)
                {
                    assert(cube_indexes[0][depth][width] != nullptr);
                    temp.push_back(cube_indexes[0][depth][width]);
                    std::cout << "Collected cube_indexes[0][" << depth << "][" << width << "]: " << cube_indexes[0][depth][width] << std::endl;
                }
            }

            for (j = 0; j < temp.size(); j++)
            {
                assert(temp[j] != nullptr);
                glm::mat4 trans = temp[j]->getTranslationMatrix();
                glm::mat4 rot = temp[j]->getRotationMatrix();

                glm::vec3 pos = glm::vec3(trans[3][0], trans[3][1], trans[3][2]);
                std::cout << "Cube " << j << " Position: " << glm::to_string(pos) << std::endl;

                glm::mat4 modelMatrix = glm::translate(glm::mat4(1.0f), -pos);
                modelMatrix = glm::rotate(modelMatrix, glm::radians(90.0f), glm::vec3(0.0f, 1.0f, 0.0f));
                modelMatrix = glm::translate(modelMatrix, pos);

                glm::mat4 final = modelMatrix * rot;
                std::cout << "Cube " << j << " Updated Rotation Matrix: " << glm::to_string(final) << std::endl;

                temp[j]->setRotationMatrix(final);
            }

            i = 0;
            for (int width = 0; width < 3; width++)
            {
                for (int depth = 3 - 1; depth >= 0; depth--)
                {
                    std::cout << "Updating cube_indexes[0][" << depth << "][" << width << "] with temp[" << i << "]" << std::endl;
                    cube_indexes[0][depth][width] = temp[i++];
                }
            }

            std::cout << "Current state of cube_indexes:" << std::endl;
            for (int height = 0; height < 3; height++)
            {
                for (int depth = 0; depth < 3; depth++)
                {
                    for (int width = 0; width < 3; width++)
                    {
                        std::cout << "cube_indexes[" << height << "][" << depth << "][" << width << "]: "
                                  << cube_indexes[height][depth][width] << std::endl;
                    }
                }
            }
            std::cout << "Down (D) rotation completed." << std::endl;
            break;

        case GLFW_KEY_UP:
            // camera->setPosition(camera-> getPosition() + ((camera->speed) * (camera->getUp())));
            // camera->setViewMatrix( glm::lookAt(camera->getPosition(), camera->getPosition() + camera->getOrientation(), camera->getUp()) );
            std::cout << "UP Pressed" << std::endl;

            camera->translateViewMatrix(-camera->getUp());
            break;
        case GLFW_KEY_DOWN:
            // camera->setPosition(camera-> getPosition() - ((camera->speed) * (camera->getUp())));
            // camera->setViewMatrix( glm::lookAt(camera->getPosition(), camera->getPosition() + camera->getOrientation(), camera->getUp()) );
            std::cout << "DOWN Pressed" << std::endl;
            camera->translateViewMatrix(camera->getUp());

            break;
        case GLFW_KEY_LEFT:
            // camera->setPosition(camera-> getPosition() - ((camera->speed) * (glm::normalize(glm::cross(camera->getOrientation(), camera->getUp())))));
            // camera->setViewMatrix( glm::lookAt(camera->getPosition(), camera->getPosition() + camera->getOrientation(), camera->getUp()) );
            std::cout << "LEFT Pressed" << std::endl;
            camera->translateViewMatrix(glm::normalize(glm::cross(camera->getOrientation(), camera->getUp())));

            break;
        case GLFW_KEY_RIGHT:
            // camera->setPosition(camera-> getPosition() + ((camera->speed) * (glm::normalize(glm::cross(camera->getOrientation(), camera->getUp())))));
            // camera->setViewMatrix( glm::lookAt(camera->getPosition(), camera->getPosition() + camera->getOrientation(), camera->getUp()) );
            std::cout << "RIGHT Pressed" << std::endl;
            camera->translateViewMatrix(-glm::normalize(glm::cross(camera->getOrientation(), camera->getUp())));

            break;
        default:
            break;
        }
    }
}

void MouseButtonCallback(GLFWwindow *window, double currMouseX, double currMouseY)
{
    if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS)
    {
        std::cout << "MOUSE LEFT Click" << std::endl;
    }
    else if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_RIGHT) == GLFW_PRESS)
    {
        std::cout << "MOUSE RIGHT Click" << std::endl;
    }
}

void CursorPosCallback(GLFWwindow *window, double currMouseX, double currMouseY)
{
    Camera *camera = (Camera *)glfwGetWindowUserPointer(window);
    if (!camera)
    {
        std::cout << "Warning: Camera wasn't set as the Window User Pointer! KeyCallback is skipped" << std::endl;
        return;
    }

    camera->m_NewMouseX = camera->m_OldMouseX - currMouseX;
    camera->m_NewMouseY = camera->m_OldMouseY - currMouseY;
    camera->m_OldMouseX = currMouseX;
    camera->m_OldMouseY = currMouseY;

    float sensitivity = 0.1f;
    float deltaX = sensitivity * camera->m_NewMouseX;
    float deltaY = sensitivity * camera->m_NewMouseY;

    if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS)
    {
        std::cout << "MOUSE LEFT Motion" << std::endl;
        glm::mat4 rotation = glm::rotate(glm::mat4(1.0f), glm::radians(deltaX), glm::vec3(0.0f, 1.0f, 0.0f));
        rotation = glm::rotate(rotation, glm::radians(deltaY), glm::vec3(1.0f, 0.0f, 0.0f));
        camera->setViewMatrix(rotation * camera->GetViewMatrix());
    }
    else if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_RIGHT) == GLFW_PRESS)
    {
        std::cout << "MOUSE RIGHT Motion" << std::endl;

        glm::vec3 horizontalDir = glm::normalize(glm::cross(camera->getOrientation(), camera->getUp()));
        glm::vec3 verticalDir = camera->getUp();
        camera->translateViewMatrix(-(float)camera->m_NewMouseX * horizontalDir);
        camera->translateViewMatrix(((float)camera->m_NewMouseY) * verticalDir);
    }
}

void ScrollCallback(GLFWwindow *window, double scrollOffsetX, double scrollOffsetY)
{
    Camera *camera = (Camera *)glfwGetWindowUserPointer(window);
    if (!camera)
    {
        std::cout << "Warning: Camera wasn't set as the Window User Pointer! ScrollCallback is skipped" << std::endl;
        return;
    }

    std::cout << "SCROLL Motion" << std::endl;
    // camera->setPosition(camera-> getPosition() + ((camera->speed * (float)scrollOffsetY) * (camera->getOrientation())));
    // camera->setViewMatrix( glm::lookAt(camera->getPosition(), camera->getPosition() + camera->getOrientation(), camera->getUp()) );
    camera->translateViewMatrix((-(float)scrollOffsetY) * camera->getOrientation());
}

void Camera::EnableInputs(GLFWwindow *window)
{
    // Set camera as the user pointer for the window
    glfwSetWindowUserPointer(window, this);

    // Handle key inputs
    glfwSetKeyCallback(window, (void (*)(GLFWwindow *, int, int, int, int))KeyCallback);

    // Handle cursor buttons
    glfwSetMouseButtonCallback(window, (void (*)(GLFWwindow *, int, int, int))MouseButtonCallback);

    // Handle cursor position and inputs on motion
    glfwSetCursorPosCallback(window, (void (*)(GLFWwindow *, double, double))CursorPosCallback);

    // Handle scroll inputs
    glfwSetScrollCallback(window, (void (*)(GLFWwindow *, double, double))ScrollCallback);
}

const glm::vec3 &Camera::getPosition() const
{
    return m_Position;
}

// Getter for Orientation
const glm::vec3 &Camera::getOrientation() const
{
    return m_Orientation;
}

// Getter for Up Vector
const glm::vec3 &Camera::getUp() const
{
    return m_Up;
}

void Camera::setPosition(const glm::vec3 &position)
{
    m_Position = position;
}

void Camera::setOrientation(const glm::vec3 &orientation)
{
    m_Orientation = orientation;
}

void Camera::setUp(const glm::vec3 &up)
{
    m_Up = up;
}

void Camera::translateViewMatrix(const glm::vec3 position)
{
    m_View = glm::translate(m_View, speed * position);
}

void Camera::rotateViewMatrix(float angle, const glm::vec3 axis)
{
    m_View = glm::rotate(m_View, angle, glm::normalize(axis));
}

void Camera::setViewMatrix(glm::mat4 other)
{
    m_View = other;
}

const RubiksCube &Camera::getRubiksCube() const
{
    return *rubi;
}